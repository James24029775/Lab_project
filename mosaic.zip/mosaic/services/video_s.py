import socket, cv2, pickle, struct
import socketserver
import threading
from http import server
import numpy as np
import ssl
from time import sleep

client_device_socket = []
client_device_addr = []
ip_list = []
video_var : np.ndarray
frame_list = []

MAX_F = 10
FRAME = [None]*MAX_F
F_INDEX = 0


class Streamer(socketserver.ThreadingMixIn, server.HTTPServer):
	allow_reuse_address = True
	daemon_threads = True

class StreamProps(server.BaseHTTPRequestHandler):

	def get_server_socket(self, server_socket):
		self.server_socket = server_socket
	def get_frame(self, frame_load):
		self.img = frame_load
	def set_Page(self,PAGE):
		self.PAGE = PAGE
	def set_Capture(self,capture):
		self.capture = capture
	def set_Quality(self,quality):
		self.quality = quality
	def set_Mode(self,mode):
		self.mode = mode
	def set_Output(self,output):
		self.output = output

	def do_GET(self):

		if self.path == '/':
			self.send_response(301)
			self.send_header('Location', '/index.html')
			self.end_headers()
		elif self.path == '/index.html':
			content = self.PAGE.encode('utf-8')
			self.send_response(200)
			self.send_header('Content-Type', 'text/html')
			self.send_header('Content-Length', len(content))
			self.end_headers()
			self.wfile.write(content)
		elif self.path == '/stream.mjpg':
			self.send_response(200)
			self.send_header('Age', 0)
			self.send_header('Cache-Control', 'no-cache, private')
			self.send_header('Pragma', 'no-cache')
			self.send_header('Content-Type', 'multipart/x-mixed-replace; boundary=FRAME')
			self.end_headers()
			
			f_index = (F_INDEX+9) % MAX_F
			try:
				while True:				
					self.wfile.write(b'--FRAME\r\n')
					self.send_header('Content-Type', 'image/jpeg')
					self.send_header('Content-Length', len(FRAME[f_index]))
					self.end_headers()

					self.wfile.write(FRAME[f_index])
					f_index = (f_index+1) % MAX_F
					self.wfile.write(b'\r\n')
					while f_index == F_INDEX:
						sleep(0.01)
			except Exception as e:
				print("A client has left...")
		else:
			self.send_error(404)
			self.end_headers()


def camera_server_conn():
	global FRAME
	global F_INDEX

	server_socket = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
	socket_address = ("0.0.0.0", 8888)
	server_socket.bind(socket_address)
	server_socket.listen(2)
	print("Camera start listening at port", socket_address[1])
	while True:
		try:
			client_socket, addr = server_socket.accept()
			print("camera connected from", addr)

			data = b""
			payload_size = struct.calcsize("Q")
			while True:
				while len(data) < payload_size:
					packet = client_socket.recv(4096) # 4K
					if not packet: break
					data+=packet
				packed_msg_size = data[:payload_size]
				data = data[payload_size:]
				msg_size = struct.unpack("Q",packed_msg_size)[0] 
				while len(data) < msg_size:
					data += client_socket.recv(4096)   
				frame_data = data[:msg_size]
				data  = data[msg_size:]
				frame_loads = pickle.loads(frame_data)
				img = frame_loads
				FRAME[F_INDEX % MAX_F] = cv2.imencode('.JPEG', img,[cv2.IMWRITE_JPEG_QUALITY,100])[1].tobytes()
				F_INDEX = (F_INDEX+1) % MAX_F
		except Exception as e:
			print(str(e))


def server_to_webpage():
	HTML="""
	<html>
	<head>
	<title> Unit Live Streaming</title>
	</head>

	<body bgcolor="#D2E9FF">
	<center><h1> Live Streaming on Unit_1 </h1></center>
	<center><img src="stream.mjpg" width='640' height='480' autoplay playsinline></center>

	</body>
	</html>
	"""
	S_props = StreamProps
	S_props.set_Page(S_props,HTML)
	S_props.set_Mode(S_props,'cv2')
	S_props.set_Quality(S_props,100)
	server_address = ('0.0.0.0', 8000)
	httpd = Streamer(server_address, S_props)
	httpd.socket = ssl.wrap_socket(httpd.socket, server_side=True, certfile='ssl.pem', ssl_version=ssl.PROTOCOL_TLS)
	print("Web start listening at port", server_address[1])
	httpd.serve_forever()


if __name__ == '__main__':
	t = threading.Thread(target=camera_server_conn)
	t.start()

	server_to_webpage()