from http.server import BaseHTTPRequestHandler, HTTPServer
from http.client import HTTPConnection
from urllib.parse import urlparse
import json
import http.client
import threading
from socketserver import ThreadingMixIn


class RequestHandler(BaseHTTPRequestHandler):

    protocol_version = 'HTTP/1.1'

    def do_POST(self):
        content_len = int(self.headers.get('content-length'))
        post_body = self.rfile.read(content_len)
        print(post_body)
        data = json.loads(post_body)
        SECRET = data["secret"]
        IP = data["ip"]
        MSG = data["msg"]
        parsed_path = urlparse(self.path)
        pathlist = parsed_path.path.split("/")
        DEVICE_NAME = pathlist[2]
        response_data = '{"response": "ok"}'
        self.send_response(200)
        self.send_header('Content-length', len(response_data))
        self.send_header("Connection", "keep-alive")
        self.end_headers()
        self.wfile.write(json.dumps({
            'response': "ok"
        }).encode())
        threading.Thread(target = self.clientHandler, args=(DEVICE_NAME, MSG, IP, SECRET)).start()


    def clientHandler(self, DEVICE_NAME, MSG, IP, SECRET):
        try:
            data_json = {'device': DEVICE_NAME, 'msg': MSG}
            exporter_data = self.exporter()
            print(exporter_data)
            #check device in which unit
            unit = -1
            for i in range(len(exporter_data["units"])):
                for j in range(len(exporter_data["units"][i]["members"])):
                    if (exporter_data["units"][i]["members"][j]["ip"] == IP
                    and exporter_data["units"][i]["members"][j]["name"] == DEVICE_NAME
                    and exporter_data["units"][i]["members"][j]["secret"] == SECRET):
                        unit = i
            #broadcast
            if unit != -1:
                for i in range(len(exporter_data["units"][unit]["members"])):
                    if exporter_data["units"][unit]["members"][i]["status"]:
                        print(exporter_data["units"][unit]["members"][i]["ip"])
                        try:
                            conn = http.client.HTTPConnection(exporter_data["units"][unit]["members"][i]["ip"], 10000)
                            headers = {'Content-type': 'application/json'}
                            conn.request('POST', '', json.dumps(data_json).encode(), headers)
                            response = conn.getresponse()
                            print(response.read().decode())
                        except Exception as e:
                            print(str(e))          
        except:
            print("clienthandler error")
           

    def exporter(self):
        try:
            conn = HTTPConnection("combat", 8080)
            path = "/exporter/"
            conn.request("GET", path)
            response = conn.getresponse()
            data = response.read().decode()
            data_dic = json.loads(data)
            return data_dic
        except:
            print("exporter error")


class ThreadingHTTPServer(ThreadingMixIn, HTTPServer):
    daemon_threads = True


if __name__ == '__main__':
    server = ThreadingHTTPServer(('0.0.0.0', 9000), RequestHandler)
    print('Server listening at port 9000')
    server.serve_forever()
