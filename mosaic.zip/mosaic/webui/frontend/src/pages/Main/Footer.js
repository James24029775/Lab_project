import React from 'react';

const Footer = () => (
  <footer className="footer">
    <div className="container-fluid">
      <nav className="pull-left">
      </nav>
    </div>
  </footer>
);

export default Footer;
