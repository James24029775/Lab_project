import React, { Component } from "react";
import { Button, DropdownButton, MenuItem } from "react-bootstrap";
import { Link, withRouter } from "react-router-dom";
import { BootstrapTable, TableHeaderColumn } from "react-bootstrap-table";
import { connect } from "react-redux";
import UEInfoApiHelper from "../../util/OnlineApiHelper";
import RatinggroupQuotaModal from "./components/RatinggroupQuotaModal";
import ApiHelper from "../../util/ApiHelper";

// import { flatMap } from "lodash";
// import Dropdown from 'react-dropdown';
// import 'react-dropdown/style.css';
// import Pagination from "react-bootstrap/Pagination";
// import paginationFactory from 'react-bootstrap-table2-paginator';

// eslint-disable-next-line no-unused-vars

class DetailButton extends Component {
  constructor(props) {
    super(props);
    this.handleClick = this.handleClick.bind(this);
  }

  handleClick(cell, row, rowIndex) {
    UEInfoApiHelper.fetchUEInfoDetail(cell).then((result) => {
      let success = result[0];
      let smContextRef = result[1];

      if (success) {
        // console.log("After fetchUEInfoDetail")
        // console.log(smContextRef)
        UEInfoApiHelper.fetchUEInfoDetailSMF(smContextRef).then();
      }
    });
  }

  render() {
    const { cell, row, rowIndex } = this.props;
    return (
      <Button
        bsStyle="primary"
        onClick={() => this.handleClick(cell, row, rowIndex)}
      >
        <Link to={`/ueinfo/${cell}`}>Show Info</Link>
      </Button>
    );
  }
}

class ServiceManagement extends Component {
  state = {
    quotaModalOpen: false,
    quotaModalData: null,
  };

  options = ["g1", "g2", "g3"];

  componentDidMount() {
    UEInfoApiHelper.fetchOnlineUnit().then(() => {
      // console.log("After fetchRegisteredUE")
      // console.log(this.props.get_registered_ue_err)
    });

    this.interval = setInterval(async () => {
      await UEInfoApiHelper.fetchOnlineUnit();
    }, 1000);
  }

  componentWillUnmount() {
    clearInterval(this.interval);
  }

  refreshTable() {
    UEInfoApiHelper.fetchOnlineUnit().then();
  }

  async openEditQuota(cell) {
    console.log("openEditQuota");

    const quota = await ApiHelper.fetchQuota(cell);
    console.log("fetchquota supi", quota["supi"]);

    this.setState({
      quotaModalOpen: true,
      quotaModalData: quota,
    });
    console.log(this.state.quotaModalData);
  }

  async addQuota(subscriberData) {
    console.log("addQuota");
    this.setState({ subscriberModalOpen: false });

    if (!(await ApiHelper.createSubscriber(subscriberData))) {
      alert("Error creating new q when create user");
    }
    ApiHelper.fetchQuota().then();
  }

  async updateQuota(quotaData) {
    console.log(
      "updateQuota   quotadata:",
      quotaData,
      "this.state.quotaModalData",
      this.state.quotaModalData
    );
    this.setState({ quotaModalOpen: false });

    let newquotaData = this.state.quotaModalData;
    newquotaData["quota"] = quotaData["quota"];
    this.setState({ quotaModalData: newquotaData });
    console.log("after updateQuota:", this.state.quotaModalData);

    const result = await ApiHelper.updateQuota(newquotaData);

    if (!result) {
      alert("Error updating quota: " + newquotaData["quota"]);
    }
    ApiHelper.fetchQuota(newquotaData["supi"]).then();
  }

  cellButton(cell, row, enumObject, rowIndex) {
    return <DetailButton cell={cell} row={row} rowIndex={rowIndex} />;
  }

  rowStyleFormat(cell, row, enumObject, rowIndexx) {
    // console.log("In rowStyleFormat")
    // console.log(cell)

    if (cell.Status === "Registered") {
      return { backgroundColor: "#4CBB17" };
    } else if (cell.Status === "Disconnected") {
      return { backgroundColor: "#CD5C5C" };
    }
    //return { backgroundColor: rowIndexx % 2 === 0 ? 'red' : 'blue' };
  }

  // const defaultSortedBy = [{
  //   dataField: "name",
  //   order: "asc"  // or desc
  // }];

  _onSelect() {}

  render() {
    return (
      <div className="content">
        <div className="container-fluid">
          <div className="dashboard__title">
            <h2>Realtime Status</h2>

            <Button
              bsStyle={"primary"}
              className="subscribers__button"
              onClick={this.refreshTable.bind(this)}
            >
              Refresh
            </Button>
          </div>
          <div className="row">
            <h3>Online Devices</h3>
            <div
              className="col-12"
              style={{ "overflow-y": "scroll", height: "300px" }}
            >
              {!this.props.get_ue_cr_err && (
                <BootstrapTable
                  data={this.props.people}
                  striped={true}
                  hover={true}
                >
                  <TableHeaderColumn
                    dataField="PersonId"
                    width="20%"
                    isKey={true}
                    dataAlign="center"
                    dataSort={true}
                  >
                    Device Name
                  </TableHeaderColumn>

                  <TableHeaderColumn
                    dataField="IP"
                    width="20%"
                    dataAlign="center"
                    dataSort={true}
                  >
                    IP
                  </TableHeaderColumn>

                  <TableHeaderColumn
                    dataField="IP"
                    width="20%"
                    dataAlign="center"
                    dataSort={true}
                  >
                    TxBitrate
                  </TableHeaderColumn>

                  <TableHeaderColumn
                    dataField="IP"
                    width="20%"
                    dataAlign="center"
                    dataSort={true}
                  >
                    RSSI
                  </TableHeaderColumn>

                  <TableHeaderColumn
                    dataField="GroupId"
                    width="20%"
                    dataSort={true}
                  >
                    Unit Id
                  </TableHeaderColumn>
                </BootstrapTable>
              )}
            </div>
            <div className="col-12">
              {this.props.get_ue_cr_err && <h2>{this.props.ue_cr_err_msg}</h2>}
            </div>
            <h3>Online Units</h3>

            <div
              className="col-12"
              style={{ "overflow-y": "scroll", height: "300px" }}
            >
              {/* <Form.Select>
                <option>1</option>
                <option>2</option>
                <option>3</option>
              </Form.Select> */}

              {!this.props.get_ue_cr_err && (
                <BootstrapTable
                  data={this.props.people}
                  striped={true}
                  hover={true}
                >
                  <TableHeaderColumn
                    dataField="PersonId"
                    width="30%"
                    isKey={true}
                    dataAlign="center"
                    dataSort={true}
                  >
                    Unit Id
                  </TableHeaderColumn>

                  <TableHeaderColumn
                    dataField="IP"
                    width="30%"
                    dataAlign="center"
                    dataSort={true}
                  >
                    Unit Name
                  </TableHeaderColumn>

                  <TableHeaderColumn
                    dataField="IP"
                    width="40%"
                    dataAlign="center"
                    dataSort={true}
                  >
                    Members
                  </TableHeaderColumn>

                  {/* <TableHeaderColumn
                    dataField="supi"
                    width="14%"
                    dataFormat={(cell, row, rowIndex, formatExtraData) => {
                      return (
                        <Button
                          bsStyle={"primary"}
                          className="subscribers__button"
                          onClick={this.openEditQuota.bind(this, cell)}
                        >
                          Modify RatinggroupQuota
                        </Button>
                      );
                    }}
                  >
                    Modify quota
                  </TableHeaderColumn> */}
                </BootstrapTable>
              )}
            </div>
          </div>
          <RatinggroupQuotaModal
            open={this.state.quotaModalOpen}
            setOpen={(val) => this.setState({ quotaModalOpen: val })}
            quota={this.state.quotaModalData}
            // quota={{quota: 7777, supi: 'imsi-208930000000003'}}

            onModify={this.updateQuota.bind(this)}
            onSubmit={this.addQuota.bind(this)}
          />
        </div>
      </div>
    );
  }
}

export default withRouter(
  connect((state) => ({
    users_cr: state.ueinfo.users_cr,
    people: state.ueinfo.people,
    get_ue_cr_err: state.ueinfo.get_ue_cr_err,
    ue_cr_err_msg: state.ueinfo.ue_cr_err_msg,
    smContextRef: state.ueinfo.smContextRef,
  }))(ServiceManagement)
);
