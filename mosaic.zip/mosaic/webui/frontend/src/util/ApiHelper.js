import Http from "./Http";
import { store } from "../index";
import userActions from "../redux/actions/userActions";
import User from "../models/User";
import axios from "axios";
import LocalStorageHelper from "./LocalStorageHelper";
import RegisteredDevice from "../models/RegisteredDevice";
import RegisteredUnit from "../models/RegisteredUnit";
import registeredActions from "../redux/actions/registeredActions";

class ApiHelper {
  static async fetchRegisteredDevices() {
    const MSG_FETCH_ERROR = "Error fetching registered devices.";

    try {
      let response = await Http.get("device/getdevice");
      if (response.status === 200 && response.data.devices) {
        const devices = response.data.devices.map(
          (val) =>
            new RegisteredDevice(
              val["deviceId"],
              val["name"],
              val["secret"],
              val["ip"],
              val["status"]
            )
        );
        store.dispatch(registeredActions.setRegisteredDevice(devices));
        return true;
      }
    } catch (error) {
      let err_msg;
      if (error.response && error.response.data) {
        err_msg = error.response.data.cause || MSG_FETCH_ERROR;
      } else {
        err_msg = MSG_FETCH_ERROR;
      }
      console.log(error.response);
      store.dispatch(registeredActions.setRegisteredDeviceError(err_msg));
    }

    return false;
  }

  static async fetchRegisteredUnits() {
    const MSG_FETCH_ERROR = "Error fetching online registered units.";

    try {
      let response = await Http.get("registered-units");
      if (response.status === 200 && response.data) {
        const units = response.data.map(
          (val) =>
            new RegisteredUnit(
              val["unitID"],
              val["unitName"],
              val["bitrateLimit"]
            )
        );
        store.dispatch(registeredActions.setRegisteredUnit(units));
        return true;
      }
    } catch (error) {
      let err_msg;
      if (error.response && error.response.data) {
        err_msg = error.response.data.cause || MSG_FETCH_ERROR;
      } else {
        err_msg = MSG_FETCH_ERROR;
      }
      console.log(error.response);
      store.dispatch(registeredActions.setRegisteredUnitError(err_msg));
    }

    return false;
  }

  static async createRegisteredDevice(deviceData) {
    try {
      let user = LocalStorageHelper.getUserInfo();
      axios.defaults.headers.common[
        "Authorization"
      ] = `Bearer ${user.accessToken}`;
      // axios.defaults.headers.common["Token"] = user.accessToken;
      if(deviceData.staticIP == null) deviceData.staticIP = "";
      let response = await Http.post(`device/` + deviceData.deviceName, {
        ip: deviceData.staticIP,
        secret: deviceData.secret,
      });
      if (response.status === 201 || response.status === 200) {
        let response = await Http.post(
          `group/combat/devices/` + deviceData.deviceName
        );
        return true;
      }
    } catch (error) {
      console.error(error);
    }

    return false;
  }

  static async createRegisteredUnit(unitData) {
    try {
      let user = LocalStorageHelper.getUserInfo();
      axios.defaults.headers.common[
        "Authorization"
      ] = `Bearer ${user.accessToken}`;

      if (unitData.bitrateLimit === "") {
        let response = await Http.post(`group/combat/unit/` + unitData.unitName);
        if (response.status === 201 || response.status === 200) {
          return true;
        }
      } else {
        let response = await Http.post(`group/combat/unit/` + unitData.unitName, {
          bitrateLimit: unitData.bitrateLimit,
        });
        if (response.status === 201 || response.status === 200) {
          return true;
        }
      }
    } catch (error) {
      console.error(error);
    }

    return false;
  }

  static async addDeviceToUnit(device, unit) {
    try {
      let user = LocalStorageHelper.getUserInfo();
      axios.defaults.headers.common[
        "Authorization"
      ] = `Bearer ${user.accessToken}`;

      let response = await Http.post(`device/${device}/join/${unit}`);
      if (response.status === 201 || response.status === 200) {
        return true;
      }
    } catch (error) {
      console.error(error);
    }

    return false;
  }

  static async deleteDeviceFromUnit(device, unit) {
    try {
      let user = LocalStorageHelper.getUserInfo();
      axios.defaults.headers.common[
        "Authorization"
      ] = `Bearer ${user.accessToken}`;

      let response = await Http.post(`device/${device}/leave/${unit}`);
      if (response.status === 201 || response.status === 200) {
        return true;
      }
    } catch (error) {
      console.error(error);
    }

    return false;
  }

  static async deleteRegisteredDevice(DeviceName) {
    let user = LocalStorageHelper.getUserInfo();
    axios.defaults.headers.common[
      "Authorization"
    ] = `Bearer ${user.accessToken}`;
    let response1 = await Http.delete(`group/combat/devices/${DeviceName}`);

    // try {
    // removeDeviceFromGroup
    // let user = LocalStorageHelper.getUserInfo();
    // axios.defaults.headers.common[
    //   "Authorization"
    // ] = `Bearer ${user.accessToken}`;
    let response2 = await Http.delete(`device/${DeviceName}`);

    if (response2.status === 204 || response2.status === 200) return true;
    // } catch (error) {
    //   console.error(error);
    // }

    return false;
  }

  static async deleteRegisteredUnit(UnitName) {
    try {
      // removeDeviceFromGroup
      let user = LocalStorageHelper.getUserInfo();
      axios.defaults.headers.common[
        "Authorization"
      ] = `Bearer ${user.accessToken}`;
      let response = await Http.delete(`group/combat/unit/${UnitName}`);

      if (response.status === 204 || response.status === 200) return true;
    } catch (error) {
      console.error(error);
    }

    return false;
  }

  static async login(username, loginRequest) {
    console.log("login");
    try {
      let response = await Http.post(
        `auth/` + username + `/login`,
        loginRequest
      );
      return response;
    } catch (error) {
      console.error(error);
    }
    return false;
  }

  static async createTenant(tenantData) {
    try {
      let user = LocalStorageHelper.getUserInfo();
      axios.defaults.headers.common["Token"] = user.accessToken;
      let response = await Http.post("tenant", tenantData);
      if (response.status === 200) return true;
    } catch (error) {
      console.error(error);
    }

    return false;
  }

  static async fetchUsers(tenantId) {
    try {
      store.dispatch(userActions.setUsers([]));
      let user = LocalStorageHelper.getUserInfo();
      axios.defaults.headers.common["Token"] = user.accessToken;
      let response = await Http.get(`tenant/${tenantId}/user`);
      if (response.status === 200 && response.data) {
        const users = response.data.map(
          (val) => new User("", "", "", val["userId"], val["email"])
        );
        store.dispatch(userActions.setUsers(users));
        return true;
      }
    } catch (error) {}

    return false;
  }

  static async fetchUserById(tenantId, id) {
    try {
      let user = LocalStorageHelper.getUserInfo();
      axios.defaults.headers.common["Token"] = user.accessToken;
      let response = await Http.get(`tenant/${tenantId}/user/${id}`);
      if (response.status === 200 && response.data) {
        return response.data;
      }
    } catch (error) {}

    return false;
  }

  static async createUser(tenantId, userData) {
    try {
      let user = LocalStorageHelper.getUserInfo();
      axios.defaults.headers.common["Token"] = user.accessToken;
      userData["encryptedPassword"] = userData["password"];
      let response = await Http.post(`tenant/${tenantId}/user`, userData);
      if (response.status === 200) return true;
    } catch (error) {
      console.error(error);
    }

    return false;
  }

  static async updateUser(tenantId, userId, userData) {
    try {
      let user = LocalStorageHelper.getUserInfo();
      axios.defaults.headers.common["Token"] = user.accessToken;
      userData["encryptedPassword"] = userData["password"];
      let response = await Http.put(
        `tenant/${tenantId}/user/${userId}`,
        userData
      );
      if (response.status === 200) return true;
    } catch (error) {
      console.error(error);
    }

    return false;
  }

  static async deleteUser(tenantId, id) {
    try {
      let user = LocalStorageHelper.getUserInfo();
      axios.defaults.headers.common["Token"] = user.accessToken;
      let response = await Http.delete(`tenant/${tenantId}/user/${id}`);
      if (response.status === 200) return true;
    } catch (error) {
      console.error(error);
    }

    return false;
  }
}

export default ApiHelper;
