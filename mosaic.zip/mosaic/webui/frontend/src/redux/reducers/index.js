import { reducer as formReducer } from "redux-form";
import auth from "./auth";
import layout from "./layout";
import subscriber from "./subscriber";
import online from "./online";
import tenant from "./tenant";
import user from "./user";
import registered from "./registered";

export default {
  auth,
  layout,
  subscriber,
  online,
  tenant,
  user,
  registered,
  form: formReducer,
};
