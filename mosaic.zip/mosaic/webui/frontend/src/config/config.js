
const config = {
  API_URL: '',

  USERNAME: 'admin',
  PASSWORD: 'abc123',
};

// [Note]
//  React's process.env is passed (configured) from npm's process.env by /config/env.js,
//  which only works when running on npm server (dev/testing purpose).
if (process.env.NODE_ENV === 'test') {
  config.API_URL = `http://localhost:${process.env.PORT}/api`;
} else {
  config.API_URL = process.env.REACT_APP_HTTP_API_URL ? process.env.REACT_APP_HTTP_API_URL : "/api";
}

// config.API_URL = "https://nginx"
// config.API_URL = "http://172.18.2.1:8080"
config.API_URL = "https://172.18.2.1:8081"

export default config;
