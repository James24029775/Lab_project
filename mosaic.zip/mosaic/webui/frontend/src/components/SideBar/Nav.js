import React, { Component } from "react";
import { Link, withRouter } from "react-router-dom";
import { GrStatusInfo } from "react-icons/gr";
import { MdDevices } from "react-icons/md";
import { FaLayerGroup } from "react-icons/fa";

class Nav extends Component {
  state = {};

  render() {
    return (
      <ul className="nav">
        <li className={this.isPathActive("/realtime_status") ? "active" : null}>
          <Link to="/realtime_status">
            <GrStatusInfo />
            &nbsp;Realtime Status
          </Link>
        </li>

        <li
          className={this.isPathActive("/device_management") ? "active" : null}
        >
          <Link to="/device_management">
            <MdDevices /> &nbsp;Device Management
          </Link>
        </li>

        <li className={this.isPathActive("/unit_management") ? "active" : null}>
          <Link to="/unit_management">
            <FaLayerGroup />
            &nbsp; Unit Management
          </Link>
        </li>

        {/* <li className={this.isPathActive('/service_management') ? 'active' : null}>
          <Link to="/service_management">
            <p>Service Management</p>
          </Link>
        </li> */}
      </ul>
    );
  }

  isPathActive(path) {
    return this.props.location.pathname.startsWith(path);
  }
}

export default withRouter(Nav);
