package WebUI

type SubsListIE struct {
	PlmnID string `json:"plmnID"`
	UeId   string `json:"ueId"`
}
