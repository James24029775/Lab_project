package WebUI

type OnlineDevice struct {
	DeviceName       string `json:"devicename"`
	IP               string `json:"ip"`
	TxBitrate        string `json:"txbitrate"`
	RSSI             string `json:"rssi"`
	UnitId           string `json:"unitid"`
}
