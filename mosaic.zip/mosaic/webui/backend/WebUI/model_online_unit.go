package WebUI

type DeviceStatus struct {
	DeviceName string `json:"deviceName"`
	Status     bool   `json:"status"`
}

type OnlineUnit struct {
	UnitId       string `json:"unitId"`
	UnitName     string `json:"unitName"`
	BitrateLimit string `json:"bitrateLimit"`
	Members      []DeviceStatus `json:"members"`
}
