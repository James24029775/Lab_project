package WebUI

import (
	// "github.com/free5gc/openapi/models"
)

type QuotaData struct {
	Quota                            int32                                     `json:"quota"`
}
