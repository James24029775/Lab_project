package WebUI

type RegisteredDevice struct {
	DeviceID   string `json:"deviceID"`
	DeviceName string `json:"deviceName"`
	Secret     string `json:"secret"`
	StaticIP   string `json:"staticIP"`
	Status     bool `json:"status"`
}
