package WebUI

type Tenant struct {
	TenantId   string `json:"tenantId"`
	TenantName string `json:"tenantName"`
}
