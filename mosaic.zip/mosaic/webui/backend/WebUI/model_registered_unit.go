package WebUI

type RegisteredUnit struct {
	UnitID       string `json:"unitID"`
	UnitName     string `json:"unitName"`
	BitrateLimit string `json:"bitrateLimit"`
}
