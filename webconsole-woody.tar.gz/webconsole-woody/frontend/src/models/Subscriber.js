
export default class Subscriber {
  id = '';
  plmn = '';

  constructor(id, plmn) {
    this.id = id;
    this.plmn = plmn;
  }
}
