package WebUI

type Tenant struct {
	MissionId         string `json:"missionId"`
	MissionName       string `json:"missionName"`
	MissionCoordinate string `json:"missionCoordinate"`
}
